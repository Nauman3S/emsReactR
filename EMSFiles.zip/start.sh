sleep 5

npm start --prefix ~/Desktop/emsReactR/ &



/usr/local/bin/node-red &



sleep 15

/usr/bin/firefox http://localhost:1880 http://localhost/phpmyadmin &

/usr/bin/anydesk 
