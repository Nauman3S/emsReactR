pkill node
pkill node-red
pkill npm

